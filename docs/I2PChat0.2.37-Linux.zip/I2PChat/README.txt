I2PChat v. 0.2.37
-----------------
* Qt v5.15 or later required
* Profile dir contents should be moved to ~/.i2pchat
* profile/www/index.html contains a custom profile template ..
  automatically filled contents is marked as [content] and
  will be substituted with values taken from your configuration
  the www directory should be copied to ~/.i2pchat/ once you have
  run I2PChat for the first time .. only index.html will be served to clients
  requesting your b32 via http; no other files will be accessible
* to use the custom event sounds, map them to events in configuration -> sound
* SAM must be enabled in I2P/I2P+ or i2pd for I2PChat to work ..
  enable/start it in I2P/I2P+ via http://127.0.0.1:7657/configclients or
  via your i2pd config file